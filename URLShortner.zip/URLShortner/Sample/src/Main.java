import java.util.*;

/**
 * Main class, contains the Driver code and the conversion process.
 */
public class Main
{
  public static long id = 2;
  
  
  /**
   * @param args Command line arguments
   * @throws Exception 
   */
  public static void main(String[] args) throws Exception
  {
    Main mainObj = new Main();
    Scanner sc = new Scanner(System.in);
    Map<String, URL> urlMaps = new HashMap<String, URL>();
    mainObj.displayOptionsToUser(urlMaps, sc);
  }
  
  
  /**
   * @param urlMaps
   * @throws Exception 
   */
  public void displayOptionsToUser(Map<String, URL> urlMaps, Scanner sc) throws Exception
  {
    System.out.println("1. Generate short URL\n"
                       + "2. Get the Long URL for the Short URL\n"
                       + "\n"
                       + "Press any other key to exit");
    String choice = sc.next();
    sc.nextLine();
    if ("1".equals(choice))
    {      
      takeInput(new URL(0, null, null), urlMaps, sc);
    }
    else if ("2".equals(choice))
    {
      getLongUrl(urlMaps); 
    }
    else
    {
      sc.close();
      System.exit(0);
    }
  }
  
  /**
   * Takes the user Input.
   * @return
   * @throws Exception 
   */
  public void takeInput(URL url, Map<String, URL> urlMaps, Scanner sc) throws Exception
  { 
    System.out.println("Hello user, welcome to the URL Shortning service. Please enter the following details");
    System.out.println("Enter Long URL");
    String longURL = sc.nextLine();
    
    // Check if the entry is not empty
    while (longURL.isBlank())
    {
      System.out.println("Dear user, URL can not be empty/blank, plese re-enter the Long URL");
      longURL = sc.nextLine();
    }
    
    // Avoiding single character short URL
    // Min 2 chars as suffix will be generated
    long urlId = 10 + id;
    id ++;
    
    url.setId(urlId);
    url.setLongURL(longURL);
    
    // Generates short URL
    // Suffix part act as a key while storing in Maps
    String urlSuffix = generateShortURL(url);
    
    // Store the url object into a map to fetch the long url when user gives the short URL
    urlMaps.put(urlSuffix, url);
    
    // Again ask for the userInput
    displayOptionsToUser(urlMaps, sc);
  }
  
  /**
   * Generates the short URL.
   * @param url URL object
   * Returns the suffix part that was generated.
   * @return
   */
  public String generateShortURL(URL url)
  {
    String alpha = "abcdefghi";
    String id = Long.toString(url.getId());
    StringBuilder shortUrl = new StringBuilder();
    for (int i=0; i<id.length(); i++)
    {
      int digit = id.charAt(i) - 48;
      shortUrl.append(alpha.charAt(digit));
    }
    
    String finalShortUrl = "http://www.su.com/"+shortUrl;
    url.setShortURL(finalShortUrl);
    System.out.println("Successful!, Short URL is generated: "+finalShortUrl);
    return shortUrl.toString();
  }
  
  /**
   * Fetches the long URL
   * @param urlMaps the URLMaps contains the URL objects
   */
  public void getLongUrl(Map<String, URL> urlMaps) throws Exception
  {
    Scanner sc = new Scanner(System.in);
    System.out.println("Please enter the short URL");
    String userInputShortURL = sc.nextLine();
    
    String suffix = getSuffixForShortURL(userInputShortURL, urlMaps, sc);
    try
    {
      System.out.println("Redirecting to: "+urlMaps.get(suffix).getLongURL());
    }
    catch(NullPointerException e)
    {
      System.out.println("There is no Long URL found for the input provided. Please try to generate a new Short URL");
    }
    
    
    // Again ask for the userInput
    displayOptionsToUser(urlMaps, sc);
  }
  
  /**
   * Returns the suffix part of the Short URL
   * @param userInputShortURL
   * @return
   * @throws Exception 
   */
  public String getSuffixForShortURL(String userInputShortURL, Map<String, URL> urlMaps, Scanner sc) throws Exception
  {
    // Check if the Short URL is valid/not
    isAValidShortURL(userInputShortURL, urlMaps, sc);
    String suffix = userInputShortURL.substring(18);
    return suffix;
  }
  
  /**
   * @param userInputShortURL
   * @param urlMaps
   * @param sc
   * @throws Exception
   */
  public void isAValidShortURL(String userInputShortURL, Map<String, URL> urlMaps, Scanner sc) throws Exception
  {
    if (!userInputShortURL.contains("http://www.su.com/"))
    {
      System.out.println("Short URL: "+userInputShortURL+" provided is invalid!");
      displayOptionsToUser(urlMaps, sc);
    }
  }   
}
