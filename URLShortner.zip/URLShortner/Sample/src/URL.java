

/**
 * URL Class, to store the every URL details.
 */
public class URL 
{
	public String longURL;
	public String shortURL;
	public long id;
	
	
  /**
   * @param longURL the User's entry.
   * @param shortURL the shorter URL.
   * @param uRLValidity whether the URL should be active for ever or for some short time.
   * @param startTime the time at which short URL generated.
   */
  public URL(long id, String longURL, String shortURL)
  {
    super();
    this.id = id;
    this.longURL = longURL;
    this.shortURL = shortURL;
  }

  /**
   * @return the longURL
   */
  public String getLongURL()
  {
    return longURL;
  }

  /**
   * @param longURL the longURL to set
   */
  public void setLongURL(String longURL)
  {
    this.longURL = longURL;
  }

  /**
   * @return the shortURL
   */
  public String getShortURL()
  {
    return shortURL;
  }

  /**
   * @param shortURL the shortURL to set
   */
  public void setShortURL(String shortURL)
  {
    this.shortURL = shortURL;
  }

  /**
   * @return the id
   */
  public long getId()
  {
    return id;
  }

  /**
   * @param id the id to set
   */
  public void setId(long id)
  {
    this.id = id;
  }
}
